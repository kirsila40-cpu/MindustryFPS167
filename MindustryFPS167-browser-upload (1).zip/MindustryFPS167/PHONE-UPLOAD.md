# Загрузка проекта с Android через официальный интерфейс

Это инструкция по переносу исходников. Успешная компиляция мода пока не подтверждена.

## Вариант 1: Codex Cloud

Откройте в Chrome https://chatgpt.com/codex . При необходимости включите «Версия для ПК».

Создайте облачную среду: Work in → Cloud → Select environment → Create environment. В другом варианте интерфейса этот раздел находится в Settings → Codex Cloud → Environments. Выберите `kirsila40-cpu/MindustryFPS167`, завершите показанную авторизацию GitHub, подготовьте и опубликуйте среду, затем создайте новую задачу.

Это отдельный путь настройки репозитория, а не повторное включение разрешений плагина в текущей беседе. Доступ зависит от тарифа и доступности Codex Cloud для аккаунта. Если выбор репозитория или запись снова не работают, используйте вариант 2.

Чтобы новая задача получила подготовленные здесь файлы, сначала загрузите `MindustryFPS167-browser-upload.zip` в корень репозитория по шагу 1 ниже. Затем попросите Codex распаковать этот архив в корень рабочей копии, сохранить `.github/workflows`, создать коммит/PR, собрать Android JAR через D8 и проверить Actions. Другая задача автоматически не получает локальные файлы этой беседы.

Официальная инструкция: https://learn.chatgpt.com/docs/environments/cloud-environments

## Вариант 2: один ZIP и GitHub Codespaces

Всё выполняется в браузере. Chrome с режимом «Версия для ПК» обычно удобнее для редактора; работа именно на вашем Android-браузере здесь не проверена.

### 1. Загрузить один архив

Скачайте `MindustryFPS167-browser-upload.zip`. Не распаковывайте его на телефоне.

Откройте https://github.com/kirsila40-cpu/MindustryFPS167/upload/main . Нажмите `choose your files`, выберите ZIP через приложение Android «Файлы» и подтвердите `Commit changes` в `main`. Если браузер предлагает только фотографии, используйте Chrome и системный выбор документов.

Обычная загрузка ZIP на GitHub не распаковывает его. На этом этапе workflow ещё не установлен.

### 2. Разрешить Codespaces запись workflow

Перед созданием Codespace откройте:

https://github.com/kirsila40-cpu/MindustryFPS167/new/main?filename=.devcontainer/devcontainer.json

Вставьте содержимое `.devcontainer/devcontainer.json` из этого проекта и подтвердите `Commit changes` в `main`. Это единственный конфигурационный файл, который нужно создать через редактор. Он запрашивает только `contents: write` и `workflows: write` для этого репозитория.

Разрешения применяются к НОВОЙ среде Codespaces. Ранее созданную среду просто перезапустить недостаточно.

### 3. Создать Codespace

В репозитории выберите ветку `main`, затем `Code → Codespaces → Create codespace on main`. Если показаны параметры машины, достаточно двух ядер. Подтвердите запрошенные права `Authorize` и дождитесь открытия веб-редактора.

Codespaces использует включённую в аккаунт GitHub квоту. Если она исчерпана, бесплатный запуск может быть недоступен. После работы остановите Codespace на https://github.com/codespaces .

### 4. Распаковать и отправить исходники

В веб-редакторе выберите `☰ → Terminal → New Terminal`. Вставьте весь блок:

```sh
set -e
cd /workspaces/MindustryFPS167
mkdir -p /tmp/fps-import
unzip -oq MindustryFPS167-browser-upload.zip -d /tmp/fps-import
cp -a /tmp/fps-import/MindustryFPS167/. .
git add .devcontainer .github src tools build.gradle settings.gradle mod.json README.md DEVELOPMENT.md VALIDATION.json PHONE-UPLOAD.md .gitignore
git commit -m "Add FPS 3D prototype for Mindustry 160.7"
git push origin main
```

Архив распаковывается на сервере GitHub; `cp .../. .` переносит также скрытые папки. Структура `.github/workflows/build.yml` сохраняется. Команды не удаляют историю и не используют force push. Указаны только файлы проекта; архив и посторонние файлы автоматически не добавляются в коммит.

### 5. Проверить сборку

Откройте https://github.com/kirsila40-cpu/MindustryFPS167/actions . После push подготовленный workflow должен запуститься. Сборка считается успешной только после успешного завершения соответствующего запуска. Если компиляция упадёт, нужны реальные логи этого запуска для исправления.

Успешный workflow из `main` должен создать prerelease с `MindustryFPS-3D.jar`; это предусмотрено конфигурацией, но пока не испытано запуском. Страница релизов: https://github.com/kirsila40-cpu/MindustryFPS167/releases .

## Источники

- Создание облачной среды Codex: https://learn.chatgpt.com/docs/environments/cloud-environments
- Создание Codespace: https://docs.github.com/en/codespaces/developing-in-a-codespace/creating-a-codespace-for-a-repository
- Разрешения Codespaces, включая `workflows: write`: https://docs.github.com/en/codespaces/managing-your-codespaces/managing-repository-access-for-your-codespaces
- Загрузка файла через GitHub в браузере: https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository

Токены, пароли и ключи в переписку передавать не требуется. Авторизация проходит на официальных страницах GitHub/OpenAI.
