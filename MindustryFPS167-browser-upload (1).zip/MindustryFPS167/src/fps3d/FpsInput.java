package fps3d;

import arc.Core;
import arc.input.InputMultiplexer;
import arc.input.InputProcessor;
import arc.input.KeyCode;
import arc.math.Mathf;
import arc.math.geom.Vec2;
import arc.scene.ui.layout.Scl;
import mindustry.Vars;
import mindustry.gen.Building;
import mindustry.gen.Call;
import mindustry.gen.Unit;
import mindustry.input.MobileInput;
import mindustry.world.Tile;

/** Client-side FPS input; movement and weapons still use Mindustry's simulation. */
public final class FpsInput implements InputProcessor{
    public final FpsMod mod;
    public float yaw = 90f, pitch;
    public boolean shooting;

    private final Vec2 movement = new Vec2();
    private int movePointer = -1, lookPointer = -1, firePointer = -1;
    private float moveX, moveY, lastLookX, lastLookY;
    private boolean forward, back, left, right, wasActive, installed;
    private Unit lastUnit;

    public FpsInput(FpsMod mod){
        this.mod = mod;
    }

    /** Scene keeps priority, including the pause dialog and our held-fire button. */
    public void install(){
        if(installed) return;
        installed = true;
        InputMultiplexer multiplexer = Core.input.getInputMultiplexer();
        int sceneIndex = multiplexer.getProcessors().indexOf(Core.scene, true);
        multiplexer.addProcessor(Math.max(0, sceneIndex + 1), this);
        // Keep native movement locked while a dialog/chat temporarily suspends FPS input.
        Vars.control.input.addLock(mod::enabled);
    }

    public void update(){
        if(!mod.active()){
            if(wasActive) reset();
            wasActive = false;
            return;
        }
        wasActive = true;
        Unit unit = Vars.player.unit();
        if(lastUnit != null && lastUnit != unit){
            lastUnit.controlWeapons(false);
            reset();
        }
        lastUnit = unit;

        // Android can cancel a gesture without delivering a normal touchUp.
        if(movePointer >= 0 && !Core.input.isTouched(movePointer)){
            movePointer = -1;
            moveX = moveY = 0f;
        }
        if(lookPointer >= 0 && !Core.input.isTouched(lookPointer)) lookPointer = -1;
        if(firePointer >= 0 && !Core.input.isTouched(firePointer)){
            firePointer = -1;
            shooting = false;
        }

        float strafe = moveX + (right ? 1f : 0f) - (left ? 1f : 0f);
        float ahead = moveY + (forward ? 1f : 0f) - (back ? 1f : 0f);
        movement.set(strafe, ahead).limit(1f);
        float sx = movement.x, sy = movement.y;
        movement.set(Mathf.cosDeg(yaw) * sy + Mathf.sinDeg(yaw) * sx,
            Mathf.sinDeg(yaw) * sy - Mathf.cosDeg(yaw) * sx).scl(unit.speed());
        unit.movePref(movement);
        if(unit.type.omniMovement || movement.isZero()) unit.lookAt(yaw);

        float range = Math.max(unit.range(), Vars.tilesize * 8f);
        Vars.player.mouseX = unit.x + Mathf.cosDeg(yaw) * range;
        Vars.player.mouseY = unit.y + Mathf.sinDeg(yaw) * range;
        if(shooting) unit.mineTile = null;
        boolean fire = shooting && !unit.activelyBuilding() && !unit.disarmed
            && !(unit.type.canBoost && unit.isFlying());
        Vars.player.boosting = false;
        Vars.player.shooting = fire;
        unit.aim(Vars.player.mouseX, Vars.player.mouseY, true);
        unit.controlWeapons(fire);
    }

    public void reset(){
        movePointer = lookPointer = firePointer = -1;
        moveX = moveY = 0f;
        forward = back = left = right = shooting = false;
        movement.setZero();
        if(lastUnit != null){
            lastUnit.controlWeapons(false);
            lastUnit = null;
        }
        if(Vars.player != null){
            Vars.player.shooting = false;
            Vars.player.boosting = false;
            if(!Vars.player.dead()){
                Vars.player.unit().controlWeapons(false);
                Vars.player.unit().movePref(movement);
            }
        }
        if(Vars.control != null && Vars.control.input instanceof MobileInput){
            MobileInput mobile = (MobileInput)Vars.control.input;
            mobile.manualShooting = false;
            mobile.target = null;
        }
    }

    public float joystickX(){
        return Math.min(Scl.scl(110f), Core.graphics.getWidth() * 0.25f);
    }

    public float joystickY(){
        return Math.min(Scl.scl(110f), Core.graphics.getHeight() * 0.25f);
    }

    public float joystickRadius(){
        return Math.min(Scl.scl(62f), Core.graphics.getWidth() * 0.14f);
    }

    public float moveX(){ return moveX; }
    public float moveY(){ return moveY; }

    void beginFire(int pointer){
        if(!mod.active() || firePointer >= 0) return;
        firePointer = pointer;
        shooting = true;
    }

    void endFire(int pointer){
        if(pointer == firePointer){
            firePointer = -1;
            shooting = false;
        }
    }

    @Override
    public boolean touchDown(int x, int y, int pointer, KeyCode button){
        if(!mod.active()) return false;
        if(!Vars.mobile && button == KeyCode.mouseLeft){
            beginFire(pointer);
        }else if(movePointer < 0 && Mathf.dst(x, y, joystickX(), joystickY()) <= joystickRadius() * 1.65f){
            movePointer = pointer;
            updateJoystick(x, y);
        }else if(lookPointer < 0 && x >= Core.graphics.getWidth() * 0.45f){
            lookPointer = pointer;
            lastLookX = x;
            lastLookY = y;
        }
        // Never let a gesture on the FPS world place a block or move the 2D camera.
        return true;
    }

    @Override
    public boolean touchDragged(int x, int y, int pointer){
        if(!mod.active()) return false;
        if(pointer == movePointer) updateJoystick(x, y);
        if(pointer == lookPointer){
            float sensitivity = 220f / Math.max(1f, Core.graphics.getWidth());
            yaw = Mathf.mod(yaw - (x - lastLookX) * sensitivity, 360f);
            pitch = Mathf.clamp(pitch + (y - lastLookY) * sensitivity, -75f, 75f);
            lastLookX = x;
            lastLookY = y;
        }
        return true;
    }

    @Override
    public boolean touchUp(int x, int y, int pointer, KeyCode button){
        boolean consumed = pointer == movePointer || pointer == lookPointer || pointer == firePointer;
        if(pointer == movePointer){
            movePointer = -1;
            moveX = moveY = 0f;
        }
        if(pointer == lookPointer) lookPointer = -1;
        endFire(pointer);
        return consumed || mod.active();
    }

    private void updateJoystick(float x, float y){
        movement.set(x - joystickX(), y - joystickY()).scl(1f / joystickRadius()).limit(1f);
        if(movement.len() < 0.12f) movement.setZero();
        moveX = movement.x;
        moveY = movement.y;
    }

    @Override
    public boolean keyDown(KeyCode key){
        if(!mod.active()) return false;
        if(key == KeyCode.w) forward = true;
        else if(key == KeyCode.s) back = true;
        else if(key == KeyCode.a) left = true;
        else if(key == KeyCode.d) right = true;
        else if(key == KeyCode.e) interact();
        else return false;
        return true;
    }

    @Override
    public boolean keyUp(KeyCode key){
        if(key == KeyCode.w) forward = false;
        else if(key == KeyCode.s) back = false;
        else if(key == KeyCode.a) left = false;
        else if(key == KeyCode.d) right = false;
        else return false;
        return mod.active();
    }

    /** Short horizontal ray for the native, two-dimensional interaction rules. */
    public void interact(){
        if(!mod.active()) return;
        Unit unit = Vars.player.unit();
        shooting = false;
        Vars.player.shooting = false;
        unit.controlWeapons(false);
        float distance = Vars.tilesize * 6f;
        Tile previous = null;
        for(float d = Vars.tilesize * 0.5f; d <= distance; d += Vars.tilesize * 0.25f){
            Tile tile = Vars.world.tileWorld(unit.x + Mathf.cosDeg(yaw) * d,
                unit.y + Mathf.sinDeg(yaw) * d);
            if(tile == null) break;
            if(tile == previous) continue;
            previous = tile;
            Building build = tile.build;
            if(build != null){
                if(!build.interactable(Vars.player.team())) return;
                if(unit.stack.amount > 0 && build.items != null && build.allowDeposit()
                    && unit.within(build, Vars.itemTransferRange)
                    && build.acceptStack(unit.item(), unit.stack.amount, unit) > 0){
                    Call.transferInventory(Vars.player, build);
                }else if(build.block.configurable && build.shouldShowConfigure(Vars.player)){
                    // Native configuration panels are anchored in the 2D world.
                    mod.disable();
                    Vars.control.input.config.showConfig(build);
                }else{
                    build.tapped();
                    if(!build.block.consumesTap && build.items != null && build.items.total() > 0){
                        mod.disable();
                        Vars.control.input.inv.showFor(build);
                    }
                }
                return;
            }
            if(unit.validMine(tile) && unit.getMineResult(tile) != null
                && unit.acceptsItem(unit.getMineResult(tile))){
                unit.mineTile = unit.mineTile == tile ? null : tile;
                return;
            }
            if(tile.solid()) return;
        }
        unit.mineTile = null;
    }
}
