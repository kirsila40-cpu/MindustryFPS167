package fps3d;

import arc.ApplicationListener;
import arc.Core;
import arc.Events;
import arc.util.Log;
import mindustry.Vars;
import mindustry.core.Version;
import mindustry.game.EventType;
import mindustry.game.EventType.Trigger;
import mindustry.mod.Mod;

/** Client-side visual/input mod. Game simulation and networking remain Mindustry's. */
public final class FpsMod extends Mod{
    public FpsWorldRenderer renderer;
    public FpsInput input;
    private FpsHud hud;
    private boolean enabled, savedHudShown, warnedVersion;

    @Override
    public void init(){
        if(Vars.headless)return;
        renderer=new FpsWorldRenderer();
        input=new FpsInput(this);
        hud=new FpsHud(this,input);
        input.install();
        hud.build();
        Events.run(Trigger.update,this::update);
        Events.run(Trigger.uiDrawBegin,this::draw);
        Events.on(EventType.WorldLoadEvent.class,e->{disable();renderer.clearWorld();});
        Events.on(EventType.ResetEvent.class,e->{disable();renderer.clearWorld();});
        Events.on(EventType.TileChangeEvent.class,e->renderer.invalidate(e.tile));
        Events.on(EventType.TileFloorChangeEvent.class,e->renderer.invalidate(e.tile));
        Events.on(EventType.TileOverlayChangeEvent.class,e->renderer.invalidate(e.tile));
        Events.on(EventType.DisposeEvent.class,e->renderer.dispose());
        Core.app.addListener(new ApplicationListener(){
            @Override public void pause(){disable();}
            @Override public void resume(){renderer.dispose();}
        });
        Log.info("[FPS 3D] API baseline v160.7; running @. Android gameplay testing is still required.",Version.combined());
    }

    private boolean hasUnit(){
        return Vars.state!=null&&Vars.state.isGame()&&Vars.player!=null&&!Vars.player.dead()&&Vars.player.unit()!=null;
    }

    public boolean active(){
        return enabled&&hasUnit()&&!Vars.state.isPaused()&&!Core.scene.hasDialog()
            &&!Core.scene.hasField()&&!Vars.ui.chatfrag.shown()
            &&!Vars.renderer.isCutscene()&&!Vars.control.input.logicCutscene;
    }

    /** Keep the native movement handler locked even while a dialog pauses FPS input. */
    public boolean enabled(){return enabled;}

    public void toggle(){
        if(enabled){disable();return;}
        if(!hasUnit())return;
        if(Core.gl20==null){Vars.ui.showInfoToast("FPS 3D: OpenGL ES 2.0 недоступен",5f);return;}
        input.reset();
        input.yaw=Vars.player.unit().rotation;
        input.pitch=0;
        savedHudShown=Vars.ui.hudfrag.shown;
        Vars.ui.hudfrag.shown=false;
        enabled=true;
        if(!warnedVersion&&(Version.build!=160||Version.revision!=7)){
            warnedVersion=true;
            // Native toasts are hidden together with hudfrag.shown in FPS mode.
            Vars.ui.showInfo("FPS 3D: API 160.7; совместимость с "+Version.buildString()+" ещё не проверена");
        }
    }

    public void disable(){
        if(enabled&&Vars.ui!=null)Vars.ui.hudfrag.shown=savedHudShown;
        enabled=false;
        if(input!=null)input.reset();
        if(hud!=null)hud.reset();
    }

    private void update(){
        if(enabled&&(!hasUnit()||Vars.renderer.isCutscene()||Vars.control.input.logicCutscene))disable();
        input.update();
    }

    private void draw(){
        if(!enabled||!hasUnit())return;
        try{
            renderer.render(input);
        }catch(RuntimeException error){
            disable();
            Log.err("[FPS 3D] Renderer stopped; restored 2D mode.",error);
            Vars.ui.showException("FPS 3D: ошибка рендера; включён 2D",error);
        }
    }

    public String statusText(){
        return "FPS 3D · "+Version.buildString()+" · "+(renderer==null?24:renderer.drawDistance)+" tiles";
    }
}
