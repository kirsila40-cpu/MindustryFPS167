package fps3d;

import java.util.Arrays;

/** Triangle data shared by the chunk and entity renderers. Positions use game x/y and height z. */
final class Geometry{
    static final int stride = 6;
    private final int limit;
    float[] data;
    int size;

    Geometry(int maxVertices){
        limit = maxVertices * stride;
        data = new float[Math.min(limit, 4096)];
    }

    void clear(){ size = 0; }
    int vertices(){ return size / stride; }

    private boolean reserve(int vertices){
        int needed = size + vertices * stride;
        if(needed > limit) return false;
        if(needed > data.length) data = Arrays.copyOf(data, Math.min(limit, Math.max(needed, data.length * 2)));
        return true;
    }

    private void vertex(float x, float y, float z, float r, float g, float b){
        data[size++] = x; data[size++] = y; data[size++] = z;
        data[size++] = r; data[size++] = g; data[size++] = b;
    }

    private void quad(float ax, float ay, float az, float bx, float by, float bz,
                      float cx, float cy, float cz, float dx, float dy, float dz,
                      float r, float g, float b){
        vertex(ax, ay, az, r, g, b); vertex(bx, by, bz, r, g, b); vertex(cx, cy, cz, r, g, b);
        vertex(ax, ay, az, r, g, b); vertex(cx, cy, cz, r, g, b); vertex(dx, dy, dz, r, g, b);
    }

    void floor(float x, float y, float z, float width, float depth, float r, float g, float b){
        if(!reserve(6)) return;
        float x0 = x-width/2, x1 = x+width/2, y0 = y-depth/2, y1 = y+depth/2;
        quad(x0,y0,z, x1,y0,z, x1,y1,z, x0,y1,z, r,g,b);
    }

    /** Five faces: the underside is buried in the floor. Admission is atomic at the vertex limit. */
    void box(float x, float y, float z, float width, float depth, float height, float r, float g, float b){
        if(!reserve(30)) return;
        float x0=x-width/2, x1=x+width/2, y0=y-depth/2, y1=y+depth/2, top=z+height;
        quad(x0,y0,top, x1,y0,top, x1,y1,top, x0,y1,top, r,g,b);
        quad(x0,y0,z, x1,y0,z, x1,y0,top, x0,y0,top, r*.64f,g*.64f,b*.64f);
        quad(x1,y1,z, x0,y1,z, x0,y1,top, x1,y1,top, r*.86f,g*.86f,b*.86f);
        quad(x0,y1,z, x0,y0,z, x0,y0,top, x0,y1,top, r*.72f,g*.72f,b*.72f);
        quad(x1,y0,z, x1,y1,z, x1,y1,top, x1,y0,top, r*.94f,g*.94f,b*.94f);
    }
}
