package fps3d;

import arc.Core;
import arc.graphics.Color;
import arc.graphics.Gl;
import arc.graphics.Mesh;
import arc.graphics.VertexAttribute;
import arc.graphics.g2d.Draw;
import arc.graphics.g3d.Camera3D;
import arc.graphics.gl.FrameBuffer;
import arc.graphics.gl.Shader;
import mindustry.Vars;
import mindustry.content.Blocks;
import mindustry.gen.Building;
import mindustry.gen.Bullet;
import mindustry.gen.Groups;
import mindustry.gen.Unit;
import mindustry.graphics.Shaders;
import mindustry.world.Block;
import mindustry.world.Tile;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/** OpenGL ES 2 perspective renderer. This replaces the displayed world image, not game simulation. */
public final class FpsWorldRenderer{
    private static final int chunkSize = 16, chunkVertices = 12000, dynamicVertices = 65520;
    private static final Color sky = new Color(.12f,.17f,.23f,1f);
    private final Camera3D camera = new Camera3D();
    private final Map<Long, Chunk> chunks = new HashMap<>();
    private final Geometry scratch = new Geometry(chunkVertices), entities = new Geometry(dynamicVertices);
    private Shader shader;
    private Mesh dynamic;
    private FrameBuffer buffer;
    private int frame, builtThisFrame, cachedTeam = -1;
    public int drawnChunks;
    public final int drawDistance = 24;

    private static final String vertexShader =
        "attribute vec3 a_position;\nattribute vec3 a_tint;\n" +
        "uniform mat4 u_proj;\nuniform vec3 u_eye;\nvarying vec3 v_tint;\nvarying float v_distance;\n" +
        "void main(){v_tint=a_tint;v_distance=length(a_position-u_eye);gl_Position=u_proj*vec4(a_position,1.0);}\n";
    private static final String fragmentShader =
        "varying vec3 v_tint;\nvarying float v_distance;\nuniform float u_far;\nuniform vec3 u_sky;\n" +
        "void main(){float fog=smoothstep(u_far*0.58,u_far,v_distance);gl_FragColor=vec4(mix(v_tint,u_sky,fog),1.0);}\n";

    private static VertexAttribute tint(){ return new VertexAttribute(3,"a_tint"); }

    private void ensureResources(){
        if(shader == null){
            shader = new Shader(vertexShader, fragmentShader);
            dynamic = new Mesh(false,dynamicVertices,0,VertexAttribute.position3,tint());
        }
        // Keep the depth buffer and fill rate affordable on Android; preserve the viewport aspect ratio.
        float scale = Math.min(.75f, 1280f / Math.max(1,Core.graphics.getWidth()));
        int w = Math.max(2,(int)(Core.graphics.getWidth()*scale));
        int h = Math.max(2,(int)(Core.graphics.getHeight()*scale));
        if(buffer == null || buffer.getWidth()!=w || buffer.getHeight()!=h){
            if(buffer != null) buffer.dispose();
            buffer = new FrameBuffer(w,h,true);
        }
    }

    public void render(FpsInput input){
        ensureResources();
        if(cachedTeam!=Vars.player.team().id){
            clearWorld();
            cachedTeam=Vars.player.team().id;
        }
        frame++;
        builtThisFrame=0;
        drawnChunks=0;
        Unit unit=Vars.player.unit();
        float tile=Vars.tilesize;
        float yaw=(float)Math.toRadians(input.yaw), pitch=(float)Math.toRadians(input.pitch);
        camera.perspective=true;
        camera.fov=76f;
        camera.near=.35f;
        camera.far=drawDistance*tile;
        camera.resize(buffer.getWidth(),buffer.getHeight());
        camera.position.set(unit.x,unit.y,unit.isFlying()?tile*2.5f:tile*.72f);
        camera.direction.set((float)(Math.cos(yaw)*Math.cos(pitch)),(float)(Math.sin(yaw)*Math.cos(pitch)),(float)Math.sin(pitch));
        camera.up.set(0,0,1);
        camera.normalizeUp();
        camera.update();
        Draw.flush();
        // GL clears respect the depth write mask inherited from the previous renderer.
        Gl.depthMask(true);
        Gl.clearDepthf(1f);
        buffer.begin(sky);
        try{
            Gl.enable(Gl.depthTest);
            Gl.depthMask(true);
            Gl.depthFunc(Gl.lequal);
            Gl.disable(Gl.cullFace);
            Gl.disable(Gl.blend);
            shader.bind();
            shader.setUniformMatrix4("u_proj",camera.combined.val);
            shader.setUniformf("u_eye",camera.position.x,camera.position.y,camera.position.z);
            shader.setUniformf("u_far",camera.far);
            shader.setUniformf("u_sky",sky.r,sky.g,sky.b);
            drawTerrain(unit);
            drawEntities(unit);
        }finally{
            Gl.depthMask(true);
            Gl.disable(Gl.depthTest);
            Gl.enable(Gl.blend);
            Gl.blendFunc(Gl.srcAlpha,Gl.oneMinusSrcAlpha);
            buffer.end();
            Draw.reset();
        }
        buffer.blit(Shaders.screenspace);
        Draw.reset();
    }

    private void drawTerrain(Unit unit){
        int cx=(int)(unit.x/Vars.tilesize)/chunkSize, cy=(int)(unit.y/Vars.tilesize)/chunkSize;
        int radius=(drawDistance+chunkSize-1)/chunkSize;
        // Centre first: a bounded two chunk upload budget per frame avoids long render stalls.
        for(int ring=0;ring<=radius;ring++){
            for(int dx=-ring;dx<=ring;dx++) for(int dy=-ring;dy<=ring;dy++){
                if(Math.max(Math.abs(dx),Math.abs(dy))!=ring) continue;
                int x=cx+dx,y=cy+dy;
                if(x<0||y<0||x*chunkSize>=Vars.world.width()||y*chunkSize>=Vars.world.height()) continue;
                float mx=(x*chunkSize+chunkSize/2f)*Vars.tilesize;
                float my=(y*chunkSize+chunkSize/2f)*Vars.tilesize;
                float range=(drawDistance+chunkSize*.71f)*Vars.tilesize;
                if(distance2(mx,my,unit.x,unit.y)>range*range) continue;
                long key=key(x,y);
                Chunk chunk=chunks.get(key);
                if(chunk==null){ chunk=new Chunk(x,y); chunks.put(key,chunk); }
                if(frame%30==0 && chunk.fogHash!=fogHash(chunk)) chunk.dirty=true;
                if(chunk.dirty && builtThisFrame<2){ rebuild(chunk); builtThisFrame++; }
                if(chunk.mesh!=null && chunk.count>0){ chunk.mesh.render(shader,Gl.triangles,0,chunk.count); drawnChunks++; }
                chunk.lastUsed=frame;
            }
        }
        Iterator<Chunk> iterator=chunks.values().iterator();
        while(iterator.hasNext()){
            Chunk chunk=iterator.next();
            if(chunk.lastUsed!=frame){ if(chunk.mesh!=null)chunk.mesh.dispose(); iterator.remove(); }
        }
    }

    private int fogHash(Chunk chunk){
        int hash=1;
        for(int x=chunk.x*chunkSize;x<(chunk.x+1)*chunkSize;x++) for(int y=chunk.y*chunkSize;y<(chunk.y+1)*chunkSize;y++){
            hash=31*hash+(discovered(x,y)?1:0);
        }
        return hash;
    }

    private boolean discovered(int x,int y){
        return !Vars.state.rules.fog || Vars.fogControl.isDiscovered(Vars.player.team(),x,y);
    }

    private void rebuild(Chunk chunk){
        scratch.clear();
        float size=Vars.tilesize;
        for(int x=chunk.x*chunkSize;x<(chunk.x+1)*chunkSize;x++) for(int y=chunk.y*chunkSize;y<(chunk.y+1)*chunkSize;y++){
            Tile tile=Vars.world.tile(x,y);
            if(tile==null||!discovered(x,y)||Vars.world.getDarkness(x,y)>=3f) continue;
            Color floor=tile.floor().mapColor;
            float variation=.94f+((x*17+y*31)&7)*.008f;
            scratch.floor(tile.worldx(),tile.worldy(),0,size,size,floor.r*variation,floor.g*variation,floor.b*variation);
            if(tile.overlay()!=Blocks.air){
                Color ore=tile.overlay().mapColor;
                scratch.floor(tile.worldx(),tile.worldy(),.025f,size*.55f,size*.55f,ore.r,ore.g,ore.b);
            }
            Block block=tile.block();
            if(block!=Blocks.air && !block.synthetic()){
                Color color=block.mapColor;
                scratch.box(tile.drawx(),tile.drawy(),0,size*block.size,size*block.size,size*(block.solid?1.25f:.5f),color.r,color.g,color.b);
            }
        }
        if(chunk.mesh==null) chunk.mesh=new Mesh(true,chunkVertices,0,VertexAttribute.position3,tint());
        chunk.count=scratch.vertices();
        if(chunk.count>0) chunk.mesh.setVertices(scratch.data,0,scratch.size);
        chunk.dirty=false;
        chunk.fogHash=fogHash(chunk);
    }

    private void drawEntities(Unit player){
        entities.clear();
        float range2=camera.far*camera.far;
        for(Building build:Groups.build){
            if(distance2(build.x,build.y,player.x,player.y)>range2 ||
                !build.isDiscovered(Vars.player.team()) || build.inFogTo(Vars.player.team())) continue;
            Color color=build.block.mapColor, team=build.team.color;
            float width=build.block.size*Vars.tilesize*.96f;
            float height=Vars.tilesize*(build.block.solid?.95f:.24f);
            entities.box(build.x,build.y,0,width,width,height,color.r,color.g,color.b);
            entities.box(build.x,build.y,height,width*.52f,width*.52f,Vars.tilesize*.08f,team.r,team.g,team.b);
        }
        int count=0;
        for(Unit unit:Groups.unit){
            if(unit==player||unit.dead||distance2(unit.x,unit.y,player.x,player.y)>range2||unit.inFogTo(Vars.player.team())) continue;
            if(count++>=160) break;
            Color color=unit.team.color;
            float width=Math.max(2f,unit.hitSize*.65f), z=unit.isFlying()?Vars.tilesize*2f:0;
            entities.box(unit.x,unit.y,z,width,width,width*.65f,color.r,color.g,color.b);
            double angle=Math.toRadians(unit.rotation);
            entities.box(unit.x+(float)Math.cos(angle)*width*.65f,unit.y+(float)Math.sin(angle)*width*.65f,z+width*.32f,width*.32f,width*.32f,width*.16f,.85f,.85f,.85f);
        }
        count=0;
        for(Bullet bullet:Groups.bullet){
            if(distance2(bullet.x,bullet.y,player.x,player.y)>range2 ||
                (Vars.state.rules.fog && !Vars.fogControl.isVisible(Vars.player.team(),bullet.x,bullet.y))) continue;
            if(count++>=256)break;
            entities.box(bullet.x,bullet.y,Vars.tilesize*.55f,1,1,1,1,.8f,.3f);
        }
        if(entities.vertices()>0){
            dynamic.setVertices(entities.data,0,entities.size);
            dynamic.render(shader,Gl.triangles,0,entities.vertices());
        }
    }

    private static float distance2(float x,float y,float ox,float oy){float dx=x-ox,dy=y-oy;return dx*dx+dy*dy;}
    private static long key(int x,int y){return ((long)x<<32)^(y&0xffffffffL);}

    public void invalidate(Tile tile){
        if(tile==null)return;
        Chunk chunk=chunks.get(key(tile.x/chunkSize,tile.y/chunkSize));
        if(chunk!=null)chunk.dirty=true;
    }

    public void clearWorld(){
        for(Chunk chunk:chunks.values())if(chunk.mesh!=null)chunk.mesh.dispose();
        chunks.clear();
    }

    public void dispose(){
        clearWorld();
        if(buffer!=null){buffer.dispose();buffer=null;}
        if(dynamic!=null){dynamic.dispose();dynamic=null;}
        if(shader!=null){shader.dispose();shader=null;}
    }

    private static final class Chunk{
        final int x,y;
        Mesh mesh;
        int count,lastUsed,fogHash;
        boolean dirty=true;
        Chunk(int x,int y){this.x=x;this.y=y;}
    }
}
