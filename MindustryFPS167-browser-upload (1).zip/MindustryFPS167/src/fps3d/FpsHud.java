package fps3d;

import arc.Core;
import arc.graphics.Color;
import arc.graphics.g2d.Draw;
import arc.graphics.g2d.Fill;
import arc.graphics.g2d.Lines;
import arc.input.KeyCode;
import arc.scene.Element;
import arc.scene.event.InputEvent;
import arc.scene.event.InputListener;
import arc.scene.event.Touchable;
import arc.scene.ui.TextButton;
import arc.scene.ui.layout.Table;
import arc.scene.ui.layout.WidgetGroup;
import mindustry.Vars;
import mindustry.graphics.Pal;
import mindustry.ui.Styles;

/** Touch UI is kept in Arc's Scene, above the perspective framebuffer. */
public final class FpsHud{
    private final FpsMod mod;
    private final FpsInput input;
    private WidgetGroup group;

    public FpsHud(FpsMod mod, FpsInput input){
        this.mod = mod;
        this.input = input;
    }

    public void build(){
        if(group != null) return;
        group = new WidgetGroup();
        group.setFillParent(true);
        group.touchable = Touchable.childrenOnly;
        group.visible(() -> Vars.state.isGame());
        Core.scene.add(group);

        Element reticle = new Element(){
            @Override
            public void draw(){
                if(!mod.active()) return;
                float scaleX = Core.scene.getWidth() / Core.graphics.getWidth();
                float scaleY = Core.scene.getHeight() / Core.graphics.getHeight();
                float cx = input.joystickX() * scaleX;
                float cy = input.joystickY() * scaleY;
                float radius = input.joystickRadius() * Math.min(scaleX, scaleY);
                Draw.color(Color.black, 0.32f);
                Fill.circle(cx, cy, radius);
                Draw.color(Pal.accent, 0.72f);
                Lines.stroke(2f);
                Lines.circle(cx, cy, radius);
                Draw.color(Color.white, 0.65f);
                Fill.circle(cx + input.moveX() * radius * 0.65f,
                    cy + input.moveY() * radius * 0.65f, radius * 0.32f);
                float x = Core.scene.getWidth() * 0.5f;
                float y = Core.scene.getHeight() * 0.5f;
                Draw.color(input.shooting ? Pal.accent : Color.white);
                Lines.stroke(1.5f);
                Lines.line(x - 10f, y, x - 3f, y);
                Lines.line(x + 3f, y, x + 10f, y);
                Lines.line(x, y - 10f, x, y - 3f);
                Lines.line(x, y + 3f, x, y + 10f);
                Draw.reset();
            }
        };
        reticle.touchable = Touchable.disabled;
        reticle.setFillParent(true);
        group.addChild(reticle);

        Table top = new Table();
        top.setFillParent(true);
        top.touchable = Touchable.childrenOnly;
        top.top().left().margin(10f);
        top.button("2D / FPS", Styles.defaultt, mod::toggle).size(108f, 44f);
        top.button("MENU", Styles.defaultt, () -> {
            input.reset();
            Vars.ui.paused.show();
        }).size(76f, 44f).padLeft(6f);
        top.row();
        top.label(mod::statusText).style(Styles.outlineLabel).left().colspan(2).padTop(4f);
        group.addChild(top);

        Table actions = new Table();
        actions.setFillParent(true);
        actions.touchable = Touchable.childrenOnly;
        actions.bottom().right().marginRight(24f).marginBottom(38f);
        actions.visible(mod::active);
        TextButton fire = new TextButton("FIRE", Styles.defaultt);
        fire.addListener(new InputListener(){
            @Override
            public boolean touchDown(InputEvent event, float x, float y, int pointer, KeyCode button){
                if(!mod.active()) return false;
                input.beginFire(pointer);
                return true;
            }

            @Override
            public void touchUp(InputEvent event, float x, float y, int pointer, KeyCode button){
                input.endFire(pointer);
            }
        });
        actions.add(fire).size(94f, 76f).row();
        actions.button("USE / MINE", Styles.defaultt, input::interact).size(126f, 50f).padTop(12f);
        group.addChild(actions);
    }

    public void reset(){
        input.reset();
    }
}
