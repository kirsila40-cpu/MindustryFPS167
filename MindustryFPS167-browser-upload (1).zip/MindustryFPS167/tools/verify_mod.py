#!/usr/bin/env python3
"""Check the actual distributable, including DEX headers and declared classes."""
import hashlib
import json
from pathlib import Path
import struct
import sys
import zipfile
import zlib


def require(condition, message):
    if not condition:
        raise ValueError(message)


def dex_classes(data):
    require(len(data) >= 112, "DEX header is truncated")
    require(data[:4] == b"dex\n" and data[7] == 0, "Invalid DEX magic")
    require(data[4:7] in (b"035", b"037", b"038", b"039", b"040", b"041"), "Unsupported DEX version")
    u32 = lambda offset: struct.unpack_from("<I", data, offset)[0]
    require(u32(32) == len(data), "DEX length does not match its header")
    require(u32(40) == 0x12345678, "Unexpected DEX endian tag")
    require(data[12:32] == hashlib.sha1(data[32:]).digest(), "DEX SHA-1 signature is invalid")
    require(u32(8) == (zlib.adler32(data[12:]) & 0xFFFFFFFF), "DEX Adler-32 checksum is invalid")
    string_count, strings = u32(56), u32(60)
    type_count, types = u32(64), u32(68)
    class_count, definitions = u32(96), u32(100)
    require(class_count > 0, "DEX contains no class definitions")
    result = set()
    for index in range(class_count):
        class_index = u32(definitions + index * 32)
        require(class_index < type_count, "DEX class type index is out of bounds")
        descriptor_index = u32(types + class_index * 4)
        require(descriptor_index < string_count, "DEX string index is out of bounds")
        offset = u32(strings + descriptor_index * 4)
        # The prefix is a ULEB128 UTF-16 length, followed by a MUTF-8 string.
        for _ in range(5):
            value = data[offset]
            offset += 1
            if value < 128:
                break
        else:
            raise ValueError("Invalid DEX string length")
        end = data.index(0, offset)
        result.add(data[offset:end].decode("utf-8"))
    return result


def verify(path):
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        require(len(names) == len(set(names)), "JAR contains duplicate paths")
        require(archive.testzip() is None, "JAR CRC check failed")
        require("mod.json" in names, "mod.json is missing")
        metadata = json.loads(archive.read("mod.json"))
        require(metadata.get("java") is True, "Metadata must declare java=true")
        main = metadata.get("main", "")
        require(main, "Main class is not declared")
        require(main.replace(".", "/") + ".class" in names, "Declared main Java class is missing")
        require(str(metadata.get("minGameVersion")) == "160", "Unexpected API compatibility claim")
        require("classes.dex" in names, "Android classes.dex is missing")
        classes = [name for name in names if name.endswith(".class")]
        require(classes, "JAR contains no Java classes")
        for name in classes:
            require(not name.startswith(("arc/", "mindustry/")), "Bundled engine class: " + name)
            bytecode = archive.read(name)
            require(bytecode[:4] == b"\xca\xfe\xba\xbe", "Invalid Java class: " + name)
            major = struct.unpack_from(">H", bytecode, 6)[0]
            require(major <= 52, "Java class exceeds Java 8 target: " + name)
        definitions = set()
        for name in names:
            if name.startswith("classes") and name.endswith(".dex"):
                definitions.update(dex_classes(archive.read(name)))
        require("L" + main.replace(".", "/") + ";" in definitions, "Declared main class is absent from Android dex")
        for descriptor in definitions:
            require(not descriptor.startswith(("Larc/", "Lmindustry/")), "Engine code was incorrectly dexed: " + descriptor)
    print(f"Verified {path.name}: {len(classes)} Java classes, {len(definitions)} dex classes; metadata, CRC and dex integrity passed.")
    print("This verifies packaging only. It does not prove Android rendering or Build 167 compatibility.")


if __name__ == "__main__":
    try:
        require(len(sys.argv) == 2, "Usage: python3 tools/verify_mod.py build/libs/MindustryFPS-3D.jar")
        verify(Path(sys.argv[1]))
    except (ValueError, KeyError, IndexError, struct.error, OSError, zipfile.BadZipFile) as error:
        print("Mod verification failed: " + str(error), file=sys.stderr)
        sys.exit(1)
