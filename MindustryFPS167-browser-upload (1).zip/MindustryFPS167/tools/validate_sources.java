import com.sun.source.util.JavacTask;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;
import javax.tools.Diagnostic;
import javax.tools.DiagnosticCollector;
import javax.tools.JavaCompiler;
import javax.tools.JavaFileObject;
import javax.tools.StandardJavaFileManager;
import javax.tools.ToolProvider;

/** Parses Java 8 syntax only. Does not resolve Mindustry imports or type-check the mod. */
public final class validate_sources {
    public static void main(String[] arguments) throws Exception {
        Path directory = Paths.get(arguments.length == 0 ? "src" : arguments[0]);
        List<File> files = new ArrayList<>();
        try (Stream<Path> paths = Files.walk(directory)) {
            paths.filter(path -> path.toString().endsWith(".java"))
                .sorted().forEach(path -> files.add(path.toFile()));
        }
        if (files.isEmpty()) throw new IllegalArgumentException("No Java sources: " + directory);
        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
        if (compiler == null) throw new IllegalStateException("A JDK compiler module is required.");
        DiagnosticCollector<JavaFileObject> diagnostics = new DiagnosticCollector<>();
        try (StandardJavaFileManager manager = compiler.getStandardFileManager(diagnostics, null, null)) {
            JavacTask task = (JavacTask) compiler.getTask(null, manager, diagnostics,
                Arrays.asList("-source", "8", "-target", "8", "-Xlint:-options", "-proc:none"), null,
                manager.getJavaFileObjectsFromFiles(files));
            // Intentionally stop before analyze()/generate(): dependencies are not available here.
            for (Object ignored : task.parse()) {}
        }
        boolean failed = false;
        for (Diagnostic<? extends JavaFileObject> diagnostic : diagnostics.getDiagnostics()) {
            if (diagnostic.getKind() == Diagnostic.Kind.ERROR) failed = true;
            System.out.println(diagnostic);
        }
        if (failed) throw new IllegalStateException("Java 8 SYNTAX ONLY validation failed.");
        System.out.println("Java 8 SYNTAX ONLY: parsed " + files.size() + " source files successfully.");
        System.out.println("No API resolution, mod compilation, D8 execution or Android runtime validation was performed.");
    }
}
