package fps3d;

/** Runs the actual dependency-free Geometry implementation, not a copied model. */
public final class GeometryCheck {
    private static int checks;

    private static void require(boolean condition, String message) {
        checks++;
        if (!condition) throw new AssertionError(message);
    }

    private static boolean near(float value, float expected) {
        return Math.abs(value - expected) < .00001f;
    }

    private static void valid(Geometry geometry) {
        require(geometry.size % (Geometry.stride * 3) == 0, "Incomplete triangle");
        require(geometry.vertices() * Geometry.stride == geometry.size, "Invalid vertex count");
        require(geometry.size <= geometry.data.length, "Geometry exceeds allocated buffer");
        for (int i = 0; i < geometry.size; i++) {
            require(!Float.isNaN(geometry.data[i]) && !Float.isInfinite(geometry.data[i]), "Non-finite vertex data");
            if (i % Geometry.stride >= 3) {
                require(geometry.data[i] >= 0 && geometry.data[i] <= 1, "Color outside [0,1]");
            }
        }
    }

    private static void triangleNormal(Geometry geometry, int vertex, int axis, float sign) {
        int a = vertex * Geometry.stride;
        int b = a + Geometry.stride;
        int c = b + Geometry.stride;
        float ux = geometry.data[b] - geometry.data[a];
        float uy = geometry.data[b + 1] - geometry.data[a + 1];
        float uz = geometry.data[b + 2] - geometry.data[a + 2];
        float vx = geometry.data[c] - geometry.data[a];
        float vy = geometry.data[c + 1] - geometry.data[a + 1];
        float vz = geometry.data[c + 2] - geometry.data[a + 2];
        float[] normal = {uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx};
        require(normal[axis] * sign > 0, "Degenerate or inward-facing triangle at vertex " + vertex);
        require(near(normal[(axis + 1) % 3], 0) && near(normal[(axis + 2) % 3], 0), "Unexpected face normal");
    }

    private static void face(Geometry geometry, int face, int axis, float plane, float normalSign, float shade) {
        for (int vertex = face * 6; vertex < face * 6 + 6; vertex++) {
            int at = vertex * Geometry.stride;
            require(near(geometry.data[at + axis], plane), "Face is not on its expected plane");
            require(near(geometry.data[at + 3], .8f * shade), "Incorrect face red channel");
            require(near(geometry.data[at + 4], .6f * shade), "Incorrect face green channel");
            require(near(geometry.data[at + 5], .4f * shade), "Incorrect face blue channel");
        }
        triangleNormal(geometry, face * 6, axis, normalSign);
        triangleNormal(geometry, face * 6 + 3, axis, normalSign);
    }

    private static void floor() {
        Geometry geometry = new Geometry(6);
        geometry.floor(10, 20, 3, 8, 10, .8f, .6f, .4f);
        require(geometry.vertices() == 6, "Floor must contain two triangles");
        valid(geometry);
        for (int vertex = 0; vertex < 6; vertex++) {
            int at = vertex * Geometry.stride;
            require(near(geometry.data[at], 6) || near(geometry.data[at], 14), "Incorrect floor X extent");
            require(near(geometry.data[at + 1], 15) || near(geometry.data[at + 1], 25), "Incorrect floor Y extent");
        }
        face(geometry, 0, 2, 3, 1, 1);
    }

    private static void box() {
        Geometry geometry = new Geometry(30);
        geometry.box(3, 5, 7, 4, 6, 8, .8f, .6f, .4f);
        require(geometry.vertices() == 30, "Box must contain five complete faces");
        valid(geometry);
        for (int vertex = 0; vertex < 30; vertex++) {
            int at = vertex * Geometry.stride;
            require(near(geometry.data[at], 1) || near(geometry.data[at], 5), "Incorrect box X extent");
            require(near(geometry.data[at + 1], 2) || near(geometry.data[at + 1], 8), "Incorrect box Y extent");
            require(near(geometry.data[at + 2], 7) || near(geometry.data[at + 2], 15), "Incorrect box Z extent");
        }
        face(geometry, 0, 2, 15, 1, 1);
        face(geometry, 1, 1, 2, -1, .64f);
        face(geometry, 2, 1, 8, 1, .86f);
        face(geometry, 3, 0, 1, -1, .72f);
        face(geometry, 4, 0, 5, 1, .94f);
    }

    private static void atomicLimits() {
        Geometry tooSmall = new Geometry(29);
        tooSmall.box(0, 0, 0, 1, 1, 1, 1, 1, 1);
        require(tooSmall.size == 0, "Rejected box left partial geometry");
        Geometry geometry = new Geometry(35);
        geometry.floor(0, 0, 0, 1, 1, 1, 1, 1);
        float[] before = java.util.Arrays.copyOf(geometry.data, geometry.size);
        geometry.box(0, 0, 0, 1, 1, 1, 1, 1, 1);
        require(geometry.vertices() == 6, "Box was partially admitted at limit");
        for (int i = 0; i < before.length; i++) require(geometry.data[i] == before[i], "Rejected primitive modified existing vertices");
        geometry.clear();
        require(geometry.size == 0 && geometry.vertices() == 0, "clear() failed");
        geometry.box(0, 0, 0, 1, 1, 1, 1, 1, 1);
        geometry.floor(0, 0, 0, 1, 1, 1, 1, 1);
        require(geometry.vertices() == 30, "Rejected floor left partial geometry");
        valid(geometry);
    }

    private static void growth() {
        Geometry geometry = new Geometry(1000);
        for (int i = 0; i < 200; i++) geometry.floor(i, 2, 3, 1, 1, .5f, .6f, .7f);
        require(geometry.vertices() == 996, "Capacity overflow or incorrect final triangle count");
        require(geometry.data.length > 4096, "Buffer growth path was not exercised");
        valid(geometry);
        for (int triangle = 0; triangle < geometry.vertices(); triangle += 3) triangleNormal(geometry, triangle, 2, 1);
    }

    public static void main(String[] arguments) {
        floor();
        box();
        atomicLimits();
        growth();
        System.out.println("GeometryCheck passed: " + checks + " assertions against the real Geometry class.");
        System.out.println("Checked finite coordinates/colors, face extents/winding, atomic capacity admission, buffer growth and triangle integrity.");
        System.out.println("This is a geometry unit check, not a Mindustry mod build or Android GPU test.");
    }
}
